package com.sqs.currencyconverter.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sqs.currencyconverter.base.TestBase;

public class CurrencyConverterPage extends TestBase{
	public static WebDriver driver;
	
	WebElement currencyToBeConverted=driver.findElement(By.cssSelector("input#from.acc_flag_input"));
	
	WebElement convertedCurrency=driver.findElement(By.cssSelector("input#to.acc_flag_input"));
	
	WebElement convertButton= driver.findElement(By.cssSelector(".uccGoButton"));
	public WebElement convertedAmount=driver.findElement(By.cssSelector(".uccResultAmount"));
	
	public void convertCurrency(String currencyEntered, String currencyCoverted )
	{
		currencyToBeConverted.click();
		currencyToBeConverted.sendKeys(currencyEntered);
		convertedCurrency.click();
		convertedCurrency.sendKeys(currencyCoverted);
		convertButton.click();
	}
}
