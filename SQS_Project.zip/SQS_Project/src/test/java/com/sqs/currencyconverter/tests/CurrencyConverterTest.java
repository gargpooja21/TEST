package com.sqs.currencyconverter.tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sqs.currencyconverter.base.TestBase;
import com.sqs.currencyconverter.pages.CurrencyConverterPage;

public class CurrencyConverterTest extends TestBase {
CurrencyConverterPage converter;
WebDriver driver;

	@BeforeMethod
	public void setup()
	{
		initialization();
		converter=new CurrencyConverterPage();
	}
	
	@Test
	public void convertCurrency()
	{
		String enteredcurrency0=prop.getProperty("currencyEntered0");
		String enteredcurrency1=prop.getProperty("currencyEntered1");
		String enteredcurrency2=prop.getProperty("currencyEntered2");
		String enteredcurrency3=prop.getProperty("currencyEntered3");
		String enteredcurrency4=prop.getProperty("currencyEntered4");
		String currencyCoverted=prop.getProperty("currencyConverted");
		
		converter.convertCurrency(enteredcurrency0, currencyCoverted);
		String convertedvalue=converter.convertedAmount.toString();
		Assert.assertSame(convertedvalue,prop.getProperty("currencyConverted0"));
		
		converter.convertCurrency(enteredcurrency1, currencyCoverted);
		String convertedvalue1 = converter.convertedAmount.toString();
		Assert.assertSame(convertedvalue1,prop.getProperty("currencyConverted1"));
		
		converter.convertCurrency(enteredcurrency2, currencyCoverted);
		String convertedvalue2 = converter.convertedAmount.toString();
		Assert.assertSame(convertedvalue2,prop.getProperty("currencyConverted2"));
		
		converter.convertCurrency(enteredcurrency3, currencyCoverted);
		String convertedvalue3 = converter.convertedAmount.toString();
		Assert.assertSame(convertedvalue3,prop.getProperty("currencyConverted3"));
		
		converter.convertCurrency(enteredcurrency4, currencyCoverted);
		String convertedvalue4 = converter.convertedAmount.toString();
		Assert.assertSame(convertedvalue4,prop.getProperty("currencyConverted4"));
	}
	
	@AfterMethod
	public void tearDown()
	{
		
		driver.quit();
	}
	
	
	
	
	
	
	
}
